// const express = require('express');
// const { getmemberships} = require('../controller/package_controller');
// const router = express.Router();

// router.route('/').get(getmemberships);

// module.exports = router();